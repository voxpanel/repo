#!/bin/sh
INSPATH="/usr/local/les"
BINPATH="/usr/local/sbin/les"

install(){
        rm -rf $INSPATH
        mkdir $INSPATH
        cp -R files/* $INSPATH
	cp README CHANGELOG COPYING.GPL $INSPATH
        chmod 640 $INSPATH/*
        chmod 750 $INSPATH/les
        ln -fs $INSPATH/les $BINPATH
}
if [ -d "$INSPATH" ]; then
	rm -rf $INSPATH
	install
else
	install
fi

echo ".: LES installed"
echo "Install path:    $INSPATH"
echo "Config path:     $INSPATH/conf.les"
echo "Executable path: $BINPATH"
